/*
 * Basic responsive mashup template
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );
var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
require.config( {
	baseUrl: ( config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {
	qlik.on( "error", function ( error ) {
		$( '#popupText' ).append( error.message + "<br>" );
		$( '#popup' ).fadeIn( 1000 );
	} );
	$( "#closePopup" ).click( function () {
		$( '#popup' ).hide();
	} );

	//callbacks -- inserted here --
	function TxResp(reply, app){
	$("#TxRe").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#TxRe").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function VAtraso(reply, app){
	$("#Atrasos").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#Atrasos").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function VCanc(reply, app){
	$("#Cancelados").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#Cancelados").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}
	
	function VoosRea(reply, app){
	$("#Realizados").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#Realizados").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}
	
	function TotalVoos(reply, app){
	$("#TVoos").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#TVoos").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function TempoCon(reply, app){
	$("#TempoConc").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#TempoConc").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function MediaConc(reply, app){
	$("#MediaCon").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#MediaCon").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function TempoResp(reply, app){
	$("#TempoResp").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#TempoResp").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}

	function Nota(reply, app){
	$("#Nota").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#Nota").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	}
	

	function GetName(reply, app3){
	$("#Name").empty();
	console.log(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);
	$("#Name").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);    //  reply,qHypercube,qDataPages[0],qMatrix[0][0],qText 
	$("#Name02").empty();
	$("#Name02").append(reply.qHyperCube.qDataPages[0].qMatrix[0][0].qText);    //  reply,qHypercube,qDataPages[0],qMatrix[0][0],qText 
	}
	
	
	
	//open apps -- inserted here --
	var app = qlik.openApp('fd361d3e-12fa-44e3-9299-8791b6d70cbc', config); 
	var app1 = qlik.openApp('cfb6b691-75c0-4493-899f-23820a034152', config);
	var app2 = qlik.openApp('e5225bf6-01f9-459d-8fdd-1c5549eb41cf', config);

	var app3 = qlik.openApp('5bad2eb0-f64b-4e1d-ad1e-2708f305a068', config);

	var app4 = qlik.openApp('5d941075-81f4-4040-a1bd-d7eb30f7baf6', config);


	
	
	

	
	
	//get objects -- inserted here --
	app.getObject('card03','QPbe');
	
	app4.getObject('lateral','uKtaMJ');
	
	app2.getObject('KPI02','bZUry');
	app2.getObject('KPI01','gwBWPbu');
	
	app1.getObject('KPI06','MVKzjX');
	
	
	
	
	
	 
	 //Aviação
	app1.getObject('KPI05','stbFGGt');
	app1.getObject('KPI04','BBBYF');   //Analise de Sentimentos
	app.getObject('card02','bZprjAn'); 
	  
	app.getObject('card01','zmQtTp');  //App Qlik Sense Template
	
	
	
	
	
	
	//create cubes and lists -- inserted here --
	app3.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "=Only({<[User Id]={'$(=OSUser())'}>} [User Name] )"
			},
			"qLabel": "=Only({<[User Id]={'$(=OSUser())'}>} [User Name] )",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},GetName);
	
	
	app1.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(avg({<Linha_Aerea={\"GOL\"}>} Nota_Atendimento), '0,00')"
			},
			"qLabel": "Num(avg({<Linha_Aerea={\"GOL\"}>} Nota_Atendimento), '0,00')",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},Nota);
	
	
	app1.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(avg({<Linha_Aerea={\"GOL\"}>} Day([Calendario.Data da Resposta]-[Calendario.Data da Postagem])), '0,00')  & ' dias'"
			},
			"qLabel": "Num(avg({<Linha_Aerea={\"GOL\"}>} Day([Calendario.Data da Resposta]-[Calendario.Data da Postagem])), '0,00')  & ' dias'",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},TempoResp);
	
	app1.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(avg({$<Linha_Aerea-={\"Gol\"}>} Nota_Atendimento), '0,00')"
			},
			"qLabel": "Num(avg({$<Linha_Aerea-={\"Gol\"}>} Nota_Atendimento), '0,00')",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},MediaConc);
	
	
	app1.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(avg({<Linha_Aerea-={\"GOL\"}>} Day([Calendario.Data da Resposta]-[Calendario.Data da Postagem])),'0,00') & ' dias'"
			},
			"qLabel": "Num(avg({<Linha_Aerea-={\"GOL\"}>} Day([Calendario.Data da Resposta]-[Calendario.Data da Postagem])),'0,00') & ' dias' ",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},TempoCon);
	
	app2.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(Count([Situacao Voo]),'00.000')"
			},
			"qLabel": "Num(Count([Situacao Voo]),'00.000')",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},TotalVoos);
	app2.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(Count(if([Situacao Voo] = 'REALIZADO',[NUmero Voo]))-Count(if([Situacao Voo] = 'CANCELADO',[NUmero Voo])),'00.000')\r\n"
			},
			"qLabel": "Num(Count(if([Situacao Voo] = 'REALIZADO',[NUmero Voo]))-Count(if([Situacao Voo] = 'CANCELADO',[NUmero Voo])),'00.000')\r\n",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},VoosRea);
	app2.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(Count(if([Situacao Voo] = 'CANCELADO',[NUmero Voo])),'000')\r\n"
			},
			"qLabel": "Num(Count(if([Situacao Voo] = 'CANCELADO',[NUmero Voo])),'000')\r\n",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},VCanc);
	app2.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "Num(Count(if(StatusPartida = 'Atraso', 'ok')),'00.000')"
			},
			"qLabel": "Num(Count(if(StatusPartida = 'Atraso', 'ok')),'00.000')",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},VAtraso);
	app1.createCube({
	"qInitialDataFetch": [
		{
			"qHeight": 1,
			"qWidth": 1
		}
	],
	"qDimensions": [],
	"qMeasures": [
		{
			"qDef": {
				"qDef": "\r\nNum((count({\n\t<Linha_Aerea={\"GOL\"}>\n    *<Fonte={\"Reclame_Aqui\"}>\n    }[Calendario.Data da Resposta])\n/count({\n\t<Linha_Aerea={\"GOL\"}>\n    *<Fonte={\"Reclame_Aqui\"}>\n    }[Calendario.Data da Postagem])),'0,0%')"
			},
			"qLabel": "\r\nNum((count({\n\t<Linha_Aerea={\"GOL\"}>\n    *<Fonte={\"Reclame_Aqui\"}>\n    }[Calendario.Data da Resposta])\n/count({\n\t<Linha_Aerea={\"GOL\"}>\n    *<Fonte={\"Reclame_Aqui\"}>\n    }[Calendario.Data da Postagem])),'0,0%')",
			"qLibraryId": null,
			"qSortBy": {
				"qSortByState": 0,
				"qSortByFrequency": 0,
				"qSortByNumeric": 0,
				"qSortByAscii": 1,
				"qSortByLoadOrder": 0,
				"qSortByExpression": 0,
				"qExpression": {
					"qv": " "
				}
			}
		}
	],
	"qSuppressZero": false,
	"qSuppressMissing": false,
	"qMode": "S",
	"qInterColumnSortOrder": [],
	"qStateName": "$"
	},TxResp);
} );